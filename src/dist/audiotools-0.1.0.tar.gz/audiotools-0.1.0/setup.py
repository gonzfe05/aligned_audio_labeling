# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['audiotools']

package_data = \
{'': ['*']}

install_requires = \
['numpy', 'praatio', 'pydantic', 'pydub']

setup_kwargs = {
    'name': 'audiotools',
    'version': '0.1.0',
    'description': 'Tools for dealing with audio',
    'long_description': '',
    'author': 'Fernando Gonzalez',
    'author_email': 'fernandogonzalez512@hotmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
