from pathlib import Path
import os
import numpy as np
from pydantic import BaseModel
from audiotools.utils import force_align, parse_textgrids



class AudioArray(BaseModel):
    array: np.ndarray
    class Config:
        arbitrary_types_allowed = True

class AudioProcessor(object):

    def __init__(self) -> None:
        self.transcriptions = []
    
    def parse_aligned_audio(self, corpus_directory: str):
        output_directory = os.path.join(Path.home(), '.cache/mfa/')
        mfa_output = force_align(corpus_directory, output_directory)
        if mfa_output.returncode == 1:
            raise ValueError(mfa_output.stderr)
        audios, transcriptions = parse_textgrids(corpus_directory, output_directory)
        return audios, transcriptions
    
    def encode_aligned_audio(self, corpus_directory: str):
        parsed, self.transcriptions = self.parse_aligned_audio(corpus_directory)
        parsed = [{'array': np.array(p.get_array_of_samples(), dtype=float)} for p in parsed]
        return [AudioArray.parse_obj(p) for p in parsed], self.transcriptions